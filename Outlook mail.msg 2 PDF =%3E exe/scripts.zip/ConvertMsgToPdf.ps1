param (
    [string]$msgPath
)

# Vérification du fichier
if (-not (Test-Path $msgPath) -or ([System.IO.Path]::GetExtension($msgPath).ToLower() -ne ".msg")) {
    Write-Error "❌ Le fichier n'existe pas ou n'est pas un .msg."
    exit 1
}

# Préparer les chemins
$baseName = [System.IO.Path]::GetFileNameWithoutExtension($msgPath)
$folder = [System.IO.Path]::GetDirectoryName($msgPath)
$htmlPath = Join-Path $folder "$baseName mail convert2.html"
$pdfPath = Join-Path $folder "$baseName mail convert2.pdf"
$folderName = Join-Path $folder "$baseName mail convert2_fichiers"  # 💡 Dossier réellement généré par Outlook

# Ouvrir Outlook et charger le mail
$outlook = New-Object -ComObject Outlook.Application
$mail = $outlook.CreateItemFromTemplate($msgPath)

# Sauver en HTML (format 5 = olHTML)
$mail.SaveAs($htmlPath, 5)

Write-Output "✅ Mail sauvegardé en HTML : $htmlPath"

# Convertir le fichier HTML en PDF avec wkhtmltopdf
$wkhtmltopdfPath = "C:\Program Files\wkhtmltopdf\bin\wkhtmltopdf.exe"  # Ajuster si besoin

if (Test-Path $wkhtmltopdfPath) {
    & $wkhtmltopdfPath $htmlPath $pdfPath
    Write-Output "✅ Fichier converti en PDF : $pdfPath"
} else {
    Write-Error "❌ wkhtmltopdf non trouvé."
}

# Supprimer le fichier HTML
Remove-Item $htmlPath -Force
Write-Output "✅ Fichier HTML supprimé : $htmlPath"

# Supprimer le dossier "_fichiers"
$maxRetries = 5
$retryCount = 0

while ((Test-Path $folderName) -and ($retryCount -lt $maxRetries)) {
    try {
        Remove-Item $folderName -Recurse -Force
        Write-Output "✅ Dossier supprimé : $folderName"
        break
    } catch {
        Write-Error "❌ Échec suppression dossier, tentative $($retryCount + 1) : $_"
        $retryCount++
        Start-Sleep -Seconds 3
    }
}

if ($retryCount -eq $maxRetries -and (Test-Path $folderName)) {
    Write-Error "❌ Dossier non supprimé après $maxRetries tentatives."
}

exit