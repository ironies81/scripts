import tkinter as tk
from datetime import datetime

def maj_heure():
    now = datetime.now()
    date_heure = now.strftime("%d/%m/%Y %H:%M:%S")
    label.config(text=f"Nous sommes le {date_heure}")
    root.after(1000, maj_heure)  # rappelle cette fonction toutes les 1000 ms (1 seconde)

root = tk.Tk()
root.title("Date et Heure")

label = tk.Label(root, font=("Arial", 14))
label.pack(padx=20, pady=20)

ok_button = tk.Button(root, text="OK", font=("Arial", 12), command=root.destroy)
ok_button.pack(pady=(0, 20))

maj_heure()  # lancement de la mise à jour

root.mainloop()
